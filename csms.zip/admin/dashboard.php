<?php
session_start();
require_once __DIR__ . '/../db.php';

// Only allow Admin
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

/* ===============================
    QUICK STATS
================================ */
$totalUsers = $mysqli->query("SELECT COUNT(*) as cnt FROM users")->fetch_assoc()['cnt'];
$totalProducts = $mysqli->query("SELECT COUNT(*) as cnt FROM products")->fetch_assoc()['cnt'];
$totalOrders = $mysqli->query("SELECT COUNT(*) as cnt FROM orders")->fetch_assoc()['cnt'];

/* ===============================
    ADD PRODUCT
================================ */
if(isset($_POST['add_product'])){
    $name = trim($_POST['name']);
    $category = trim($_POST['category']);
    $price = trim($_POST['price']);
    $stock = trim($_POST['stock']);
    $imageFile = $_FILES['image'] ?? null;
    $imageName = null;

    $uploadDir = __DIR__ . "/uploads/";
    if(!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    if($imageFile && $imageFile['tmp_name']){
        $ext = pathinfo($imageFile['name'], PATHINFO_EXTENSION);
        $imageName = uniqid() . "." . $ext;
        move_uploaded_file($imageFile['tmp_name'], $uploadDir . $imageName);
    }

    if($name && $price && $stock){
        $stmt = $mysqli->prepare("INSERT INTO products (name, category, price, stock, image) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdis", $name, $category, $price, $stock, $imageName);
        $stmt->execute();
        header('Location: dashboard.php');
        exit;
    }
}

/* ===============================
    EDIT PRODUCT
================================ */
if(isset($_POST['edit_product'])){
    $id = intval($_POST['product_id']);
    $name = trim($_POST['name']);
    $category = trim($_POST['category']);
    $price = trim($_POST['price']);
    $stock = trim($_POST['stock']);
    $imageFile = $_FILES['image'] ?? null;

    $uploadDir = __DIR__ . "/uploads/";

    if($imageFile && $imageFile['tmp_name']){
        $ext = pathinfo($imageFile['name'], PATHINFO_EXTENSION);
        $imageName = uniqid() . "." . $ext;
        move_uploaded_file($imageFile['tmp_name'], $uploadDir . $imageName);

        $oldImg = $mysqli->query("SELECT image FROM products WHERE id=$id")->fetch_assoc()['image'];
        if($oldImg && file_exists($uploadDir.$oldImg)) unlink($uploadDir.$oldImg);

        $stmt = $mysqli->prepare("UPDATE products SET name=?, category=?, price=?, stock=?, image=? WHERE id=?");
        $stmt->bind_param("ssdisi", $name, $category, $price, $stock, $imageName, $id);
    } else {
        $stmt = $mysqli->prepare("UPDATE products SET name=?, category=?, price=?, stock=? WHERE id=?");
        $stmt->bind_param("ssdsi", $name, $category, $price, $stock, $id);
    }
    $stmt->execute();
    header('Location: dashboard.php');
    exit;
}

/* ===============================
    DELETE PRODUCT
================================ */
if(isset($_GET['delete_product'])){
    $id = intval($_GET['delete_product']);
    $imgRes = $mysqli->query("SELECT image FROM products WHERE id=$id")->fetch_assoc();
    if($imgRes && $imgRes['image'] && file_exists(__DIR__ . "/uploads/" . $imgRes['image'])){
        unlink(__DIR__ . "/uploads/" . $imgRes['image']);
    }
    $stmt = $mysqli->prepare("DELETE FROM products WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header('Location: dashboard.php');
    exit;
}

/* ===============================
    EDIT USER ROLE
================================ */
if(isset($_POST['edit_user_role'])){
    $uid = intval($_POST['user_id']);
    $newRole = $_POST['role'];

    if($newRole !== "customer"){ // customers cannot be edited
        $stmt = $mysqli->prepare("UPDATE users SET role=? WHERE id=?");
        $stmt->bind_param("si", $newRole, $uid);
        $stmt->execute();
    }

    header("Location: dashboard.php");
    exit;
}

/* ===============================
    FETCH DATA
================================ */
$usersList = $mysqli->query("SELECT id, role, name, email, address, contact, created_at FROM users ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
$productsList = $mysqli->query("SELECT id, name, category, price, stock, image, created_at FROM products ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
$ordersList = $mysqli->query("SELECT o.id, u.name as customer_name, o.total_amount, o.status, o.created_at FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard - Modern CSMS</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
/* ========== YOUR ENTIRE CSS IS UNCHANGED ========== */
<?php /* Keeping all your original CSS exactly as you provided */ ?>
body { font-family: 'Poppins', sans-serif; margin:0; background:#f7f9fc; }
header { background: linear-gradient(90deg, #ff6b6b, #ff8787); color:#fff; padding:20px 30px; display:flex; justify-content:space-between; align-items:center; box-shadow:0 4px 15px rgba(0,0,0,0.1);}
header a { color:#fff; text-decoration:none; font-weight:600; transition:0.3s; }
header a:hover { text-decoration:underline; }
.container { max-width:1200px; margin:40px auto; padding:0 20px; }

/* Quick Stats */
.stats { display:flex; gap:20px; flex-wrap:wrap; margin-bottom:40px; }
.card { flex:1; background:#fff; padding:25px; border-radius:15px; box-shadow:0 10px 25px rgba(0,0,0,0.08); text-align:center; min-width:180px; transition:0.3s; }
.card:hover { transform:translateY(-5px); }
.card h3 { margin-bottom:15px; color:#555; font-weight:500; font-size:1.1rem; }
.card span { font-size:2.2rem; font-weight:700; color:#ff6b6b; }

/* Tables */
.table { width:100%; border-collapse:collapse; background:#fff; border-radius:12px; overflow:hidden; box-shadow:0 10px 25px rgba(0,0,0,0.08); margin-bottom:50px; }
.table th, .table td { padding:14px 18px; text-align:left; border-bottom:1px solid #eee; vertical-align: middle; font-size:0.95rem; }
.table th { background:#f1f3f6; color:#555; font-weight:600; }
.table tr:hover { background:#f9f9f9; }

/* Buttons */
button { padding:8px 14px; border:none; border-radius:8px; cursor:pointer; font-weight:500; transition:0.3s; }
button:hover { opacity:0.85; }
.btn-add { background:#4e73df; color:#fff; margin-bottom:10px; }

/* Classy Action Buttons */
.action-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 14px;
    border: none;
    border-radius: 8px;
    font-weight: 500;
    font-size: 0.9rem;
    cursor: pointer;
    transition: 0.3s;
    box-shadow: 0 3px 8px rgba(0,0,0,0.12);
}

/* Edit Button Style */
.edit-btn {
    background: linear-gradient(135deg, #1cc88a, #17a673);
    color: #fff;
}
.edit-btn:hover {
    background: linear-gradient(135deg, #17a673, #13875f);
    transform: translateY(-2px);
    box-shadow: 0 5px 12px rgba(0,0,0,0.18);
}

/* Delete Button Style */
.delete-btn {
    background: linear-gradient(135deg, #e74a3b, #c0392b);
    color: #fff;
}
.delete-btn:hover {
    background: linear-gradient(135deg, #c0392b, #a93226);
    transform: translateY(-2px);
    box-shadow: 0 5px 12px rgba(0,0,0,0.18);
}

.action-btn i { font-size: 1rem; }

/* Status badges */
.status-admin { color:#fff; background:#ff6b6b; padding:5px 12px; border-radius:20px; font-weight:500; font-size:0.8rem; }
.status-staff { color:#fff; background:#4e73df; padding:5px 12px; border-radius:20px; font-weight:500; font-size:0.8rem; }
.status-customer { color:#fff; background:#1cc88a; padding:5px 12px; border-radius:20px; font-weight:500; font-size:0.8rem; }
.status-pending { color:#fff; background:#f0ad4e; padding:5px 12px; border-radius:20px; font-weight:500; font-size:0.8rem; }
.status-completed { color:#fff; background:#1cc88a; padding:5px 12px; border-radius:20px; font-weight:500; font-size:0.8rem; }
.status-cancelled { color:#fff; background:#e74a3b; padding:5px 12px; border-radius:20px; font-weight:500; font-size:0.8rem; }

/* Modals */
.modal { display:none; position:fixed; z-index:999; left:0; top:0; width:100%; height:100%; overflow:auto; background-color: rgba(0,0,0,0.6); }
.modal-content { background:#fff; margin:8% auto; padding:25px; border-radius:15px; width:90%; max-width:450px; box-shadow:0 10px 30px rgba(0,0,0,0.15); }
.close { color:#aaa; float:right; font-size:28px; font-weight:bold; cursor:pointer; transition:0.3s; }
.close:hover { color:#333; }
input, select { width:100%; padding:12px; margin:12px 0; border-radius:10px; border:1px solid #ccc; font-size:0.95rem; }
img.product-img { width:50px; height:50px; object-fit:cover; border-radius:8px; }

/* Responsive */
@media (max-width:768px){
    .stats { flex-direction:column; }
    .table th, .table td { font-size:0.85rem; }
}
</style>

</head>
<body>

<header>
    <span><i class="fas fa-tachometer-alt"></i> Modern Admin Dashboard</span>
    <a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</header>

<div class="container">

<!-- Quick Stats -->
<h2>Quick Stats</h2>
<div class="stats">
    <div class="card"><h3>Total Users</h3><span><?= $totalUsers ?></span></div>
    <div class="card"><h3>Total Products</h3><span><?= $totalProducts ?></span></div>
    <div class="card"><h3>Total Orders</h3><span><?= $totalOrders ?></span></div>
</div>

<!-- User Management -->
<h2>Users Management</h2>
<table class="table">
<thead>
<tr><th>ID</th><th>Role</th><th>Name</th><th>Email</th><th>Address</th><th>Contact</th><th>Joined</th><th>Action</th></tr>
</thead>
<tbody>
<?php foreach($usersList as $u): ?>
<tr>
<td><?= $u['id'] ?></td>
<td>
<?php
switch($u['role']){
    case 'admin': echo '<span class="status-admin">Admin</span>'; break;
    case 'staff': echo '<span class="status-staff">Staff</span>'; break;
    default: echo '<span class="status-customer">Customer</span>';
}
?>
</td>
<td><?= htmlspecialchars($u['name']) ?></td>
<td><?= htmlspecialchars($u['email']) ?></td>
<td><?= htmlspecialchars($u['address']) ?></td>
<td><?= htmlspecialchars($u['contact']) ?></td>
<td><?= htmlspecialchars($u['created_at']) ?></td>
<td>
<?php if($u['role'] !== 'customer'): ?>
    <button class="action-btn edit-btn"
    onclick='openRoleModal(<?= $u["id"] ?>, <?= json_encode($u["role"]) ?>)'>
        <i class="fas fa-pen"></i> Edit
    </button>
<?php endif; ?>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<!-- Products -->
<h2>Products Management</h2>
<button class="btn-add" onclick="document.getElementById('addModal').style.display='block'">
    <i class="fas fa-plus"></i> Add Product
</button>

<table class="table">
<thead>
<tr><th>ID</th><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Added</th><th>Action</th></tr>
</thead>
<tbody>

<?php foreach($productsList as $p): ?>
<tr>
<td><?= $p['id'] ?></td>
<td>
<?php if($p['image']): ?>
<img src="uploads/<?= htmlspecialchars($p['image']) ?>" class="product-img">
<?php endif; ?>
</td>
<td><?= htmlspecialchars($p['name']) ?></td>
<td><?= htmlspecialchars($p['category']) ?></td>
<td><?= htmlspecialchars($p['price']) ?></td>
<td><?= htmlspecialchars($p['stock']) ?></td>
<td><?= htmlspecialchars($p['created_at']) ?></td>

<td>
<button class="action-btn edit-btn"
onclick='openEditModal(
    <?= $p["id"] ?>,
    <?= json_encode($p["name"]) ?>,
    <?= json_encode($p["category"]) ?>,
    <?= json_encode($p["price"]) ?>,
    <?= json_encode($p["stock"]) ?>
)'>
    <i class="fas fa-pen"></i> Edit
</button>

<form method="get" style="display:inline;" onsubmit="return confirm('Delete this product?');">
    <input type="hidden" name="delete_product" value="<?= $p['id'] ?>">
    <button class="action-btn delete-btn"><i class="fas fa-trash"></i> Delete</button>
</form>
</td>

</tr>
<?php endforeach; ?>

</tbody>
</table>

<!-- Orders -->
<h2>Orders Management</h2>
<table class="table">
<thead>
<tr><th>ID</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th></tr>
</thead>
<tbody>
<?php foreach($ordersList as $o): ?>
<tr>
<td><?= $o['id'] ?></td>
<td><?= htmlspecialchars($o['customer_name']) ?></td>
<td><?= htmlspecialchars($o['total_amount']) ?></td>
<td>
<?php
switch($o['status']){
    case 'pending': echo '<span class="status-pending">Pending</span>'; break;
    case 'completed': echo '<span class="status-completed">Completed</span>'; break;
    case 'cancelled': echo '<span class="status-cancelled">Cancelled</span>'; break;
}
?>
</td>
<td><?= htmlspecialchars($o['created_at']) ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>


<!-- ADD PRODUCT MODAL -->
<div id="addModal" class="modal">
<div class="modal-content">
<span class="close" onclick="document.getElementById('addModal').style.display='none'">&times;</span>
<h3>Add Product</h3>

<form method="post" enctype="multipart/form-data">
<input type="text" name="name" placeholder="Product Name" required>
<input type="text" name="category" placeholder="Category" required>
<input type="number" step="0.01" name="price" placeholder="Price" required>
<input type="number" name="stock" placeholder="Stock" required>
<input type="file" name="image" accept="image/*" required>
<button type="submit" name="add_product" class="btn-add">Add Product</button>
</form>

</div>
</div>


<!-- EDIT PRODUCT MODAL -->
<div id="editModal" class="modal">
<div class="modal-content">
<span class="close" onclick="document.getElementById('editModal').style.display='none'">&times;</span>
<h3>Edit Product</h3>

<form method="post" enctype="multipart/form-data">
<input type="hidden" name="product_id" id="edit_product_id">
<input type="text" name="name" id="edit_name" required>
<input type="text" name="category" id="edit_category" required>
<input type="number" step="0.01" name="price" id="edit_price" required>
<input type="number" name="stock" id="edit_stock" required>
<input type="file" name="image" accept="image/*">
<button type="submit" name="edit_product" class="btn-add">Update Product</button>
</form>

</div>
</div>

<!-- EDIT USER ROLE MODAL -->
<div id="roleModal" class="modal">
<div class="modal-content">
<span class="close" onclick="document.getElementById('roleModal').style.display='none'">&times;</span>
<h3>Edit User Role</h3>

<form method="post">
<input type="hidden" name="user_id" id="role_user_id">
<select name="role" id="role_select">
    <option value="admin">Admin</option>
    <option value="staff">Staff</option>
</select>

<button type="submit" name="edit_user_role" class="btn-add">Update Role</button>
</form>

</div>
</div>

</div> <!-- container -->

<script>
/* Close modals */
window.onclick = function(e){
    if(e.target === document.getElementById('addModal')) addModal.style.display = "none";
    if(e.target === document.getElementById('editModal')) editModal.style.display = "none";
    if(e.target === document.getElementById('roleModal')) roleModal.style.display = "none";
}

function openEditModal(id, name, category, price, stock){
    document.getElementById('edit_product_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_category').value = category;
    document.getElementById('edit_price').value = price;
    document.getElementById('edit_stock').value = stock;
    document.getElementById('editModal').style.display = 'block';
}

function openRoleModal(id, role){
    document.getElementById('role_user_id').value = id;
    document.getElementById('role_select').value = role;
    document.getElementById('roleModal').style.display = 'block';
}
</script>

</body>
</html>
