<?php
session_start();
require_once __DIR__ . '/../db.php';

// Only allow Customers
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    header('Location: ../auth/login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['name'] ?? 'Customer';

// --- Fetch Cart Items ---
$cartItemsList = [];
$cartTotal = 0;
$cartResult = $mysqli->query("SELECT c.id, c.product_id, c.quantity, p.name, p.price, p.image 
                              FROM cart c 
                              JOIN products p ON c.product_id = p.id
                              WHERE c.user_id = $userId");
if($cartResult) {
    $cartItemsList = $cartResult->fetch_all(MYSQLI_ASSOC);
    foreach($cartItemsList as $item){
        $cartTotal += $item['price'] * $item['quantity'];
    }
}

// --- Fetch Quick Stats ---
$totalOrders = $mysqli->query("SELECT COUNT(*) as cnt FROM orders WHERE user_id=$userId")->fetch_assoc()['cnt'];
$totalSpent = $mysqli->query("SELECT SUM(total_amount) as sum FROM orders WHERE user_id=$userId")->fetch_assoc()['sum'] ?? 0;
$totalCartItems = count($cartItemsList);

// --- Fetch Products ---
$productsList = [];
$productsResult = $mysqli->query("SELECT id, name, category, price, stock, image FROM products ORDER BY created_at DESC");
if($productsResult) $productsList = $productsResult->fetch_all(MYSQLI_ASSOC);

// --- Fetch Orders ---
$ordersList = [];
$ordersResult = $mysqli->query("SELECT o.id, o.total_amount, o.status, o.created_at 
                                FROM orders o 
                                WHERE o.user_id = $userId
                                ORDER BY o.created_at DESC");
if($ordersResult) $ordersList = $ordersResult->fetch_all(MYSQLI_ASSOC);

// Local uploaded example image (from conversation assets)
$example_local_image = '/mnt/data/36aee547-1db6-4673-b630-f64caea04e77.png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customer Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
/* ---- Global ---- */
body {
    margin:0;
    font-family:'Poppins', sans-serif;
    background: #f7f9fc;
    color: #444;
}
h2 { font-size:1.4rem; margin-bottom:15px; color:#222; }
.container { max-width:1200px; margin:30px auto; padding:0 15px; }

/* ---- Header ---- */
header {
    background: linear-gradient(90deg, #1cc88a, #17a673);
    color:#fff;
    padding:20px 30px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    border-radius:0 0 15px 15px;
    box-shadow:0 5px 20px rgba(0,0,0,0.08);
}
header a { color:#fff; text-decoration:none; font-weight:600; transition:0.3s; }
header a:hover { text-decoration:underline; }

/* ---- Stats ---- */
.stats { display:flex; flex-wrap:wrap; gap:20px; margin-bottom:35px; }
.card {
    flex:1;
    min-width:150px;
    background: linear-gradient(135deg, #1cc88a, #17a673);
    color:#fff;
    padding:20px 15px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    text-align:center;
    transition:0.3s;
}
.card:hover { transform:translateY(-5px); box-shadow:0 12px 28px rgba(0,0,0,0.12); }
.card h3 { margin-bottom:10px; font-size:0.95rem; font-weight:500; }
.card span { font-size:2rem; font-weight:700; }

/* ---- Cart ---- */
.cart {
    background:#fff;
    border-radius:15px;
    box-shadow:0 8px 20px rgba(0,0,0,0.08);
    padding:20px;
    margin-bottom:30px;
}
.cart h3 { font-size:1.2rem; margin-bottom:15px; }
.cart table { width:100%; border-collapse:collapse; }
.cart th, .cart td {
    padding:10px;
    border-bottom:1px solid #eee;
    font-size:0.9rem;
    text-align:left;
}
.cart td img { width:50px; height:50px; object-fit:cover; border-radius:8px; margin-right:8px; vertical-align:middle; }
.cart-total { text-align:right; font-weight:bold; font-size:1rem; margin-top:12px; }
.place-order-btn {
    padding:10px 18px;
    border:none;
    border-radius:10px;
    background: linear-gradient(135deg,#1cc88a,#17a673);
    color:#fff;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
}
.place-order-btn:hover { background: linear-gradient(135deg,#17a673,#13875f); transform:translateY(-2px); box-shadow:0 5px 12px rgba(0,0,0,0.15); }

/* ---- Products ---- */
.products {
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(160px,1fr));
    gap:15px;
    margin-bottom:40px;
}
.product-card {
    background:#fff;
    border-radius:15px;
    overflow:hidden;
    box-shadow:0 8px 20px rgba(0,0,0,0.08);
    text-align:center;
    padding:12px;
    display:flex;
    flex-direction:column;
    transition:0.3s;
}
.product-card:hover { transform:translateY(-4px); box-shadow:0 12px 25px rgba(0,0,0,0.12); }

/* ====== UPDATED IMAGE STYLE: larger & show full dress ====== */
.product-card img {
    width:100%;
    height:260px;       /* increased height to make product more viewable */
    object-fit:contain; /* show whole item without cropping */
    background: #fff;   /* clean background area */
    border-radius:10px;
    margin-bottom:8px;
}
.product-card h4 { margin:5px 0 3px; font-size:0.95rem; font-weight:600; color:#222; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.product-card p { margin:2px 0; font-weight:500; color:#555; font-size:0.85rem; }
.product-card form { margin-top:auto; display:flex; flex-direction: column; gap:6px; }
.product-card input[type="number"] {
    padding:6px;
    border-radius:8px;
    border:1px solid #ccc;
    font-size:0.85rem;
    text-align:center;
}
.product-card button {
    padding:8px 10px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    color:#fff;
    background: linear-gradient(135deg,#1cc88a,#17a673);
    font-weight:600;
    transition:0.3s;
}
.product-card button:hover {
    background: linear-gradient(135deg,#17a673,#13875f);
    transform:translateY(-2px);
    box-shadow:0 4px 12px rgba(0,0,0,0.12);
}

/* ---- Orders Table ---- */
.table { width:100%; border-collapse:collapse; background:#fff; border-radius:15px; overflow:hidden; box-shadow:0 10px 25px rgba(0,0,0,0.08); margin-bottom:50px; }
.table th, .table td { padding:12px 15px; border-bottom:1px solid #eee; text-align:left; vertical-align: middle; font-size:0.85rem; }
.table th { background:#f5f5f5; font-weight:600; color:#222; }
.table tr:hover { background:#f9f9f9; }
.status-pending { color:#fff; background:#f0ad4e; padding:5px 10px; border-radius:12px; font-weight:600; font-size:0.8rem; }
.status-completed { color:#fff; background:#1cc88a; padding:5px 10px; border-radius:12px; font-weight:600; font-size:0.8rem; }
.status-cancelled { color:#fff; background:#d9534f; padding:5px 10px; border-radius:12px; font-weight:600; font-size:0.8rem; }

/* ---- Responsive ---- */
@media(max-width:768px){
    .products { grid-template-columns:repeat(auto-fill,minmax(140px,1fr)); }
    header { flex-direction:column; gap:10px; }
}
</style>
</head>
<body>
<header>
    <span><i class="fas fa-user-circle"></i> Welcome, <?= htmlspecialchars($userName) ?></span>
    <a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</header>

<div class="container">

<!-- Quick Stats -->
<h2>Quick Stats</h2>
<div class="stats">
    <div class="card"><h3>Total Orders</h3><span><?= $totalOrders ?></span></div>
    <div class="card"><h3>Total Spent</h3><span>$<?= number_format($totalSpent,2) ?></span></div>
    <div class="card"><h3>Cart Items</h3><span><?= $totalCartItems ?></span></div>
</div>

<!-- Cart Display -->
<?php if($cartItemsList): ?>
<div class="cart">
<h3>Your Cart</h3>
<table>
<tr><th>Item</th><th>Price</th><th>Quantity</th><th>Subtotal</th></tr>
<?php foreach($cartItemsList as $item): ?>
<tr>
<?php
// Prefer product image from admin uploads; fallback to example local image provided in conversation asset
$cart_img_path = '../admin/uploads/' . ($item['image'] ?: '');
if(!file_exists(__DIR__ . '/../admin/uploads/' . ($item['image'] ?: ''))){
    $cart_img_path = $example_local_image;
}
?>
<td><img src="<?= htmlspecialchars($cart_img_path) ?>" alt="<?= htmlspecialchars($item['name']) ?>"> <?= htmlspecialchars($item['name']) ?></td>
<td>$<?= htmlspecialchars($item['price']) ?></td>
<td><?= htmlspecialchars($item['quantity']) ?></td>
<td>$<?= number_format($item['price'] * $item['quantity'],2) ?></td>
</tr>
<?php endforeach; ?>
</table>
<div class="cart-total">Total: $<?= number_format($cartTotal,2) ?></div>
<form action="place_order.php" method="post" style="text-align:right; margin-top:10px;">
    <button type="submit" class="place-order-btn"><i class="fas fa-check"></i> Place Order</button>
</form>
</div>
<?php endif; ?>

<!-- Browse Products -->
<h2>Products</h2>
<div class="products">
<?php foreach($productsList as $p): ?>
<div class="product-card">
<?php
// Prefer product image from admin uploads; fallback to example local image provided in conversation asset
$img_rel_path = '../admin/uploads/' . ($p['image'] ?: '');
if(!file_exists(__DIR__ . '/../admin/uploads/' . ($p['image'] ?: ''))){
    $img_rel_path = $example_local_image;
}
?>
<img src="<?= htmlspecialchars($img_rel_path) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
<h4><?= htmlspecialchars($p['name']) ?></h4>
<p>$<?= htmlspecialchars($p['price']) ?></p>
<p>Stock: <?= htmlspecialchars($p['stock']) ?></p>
<form method="post" action="add_to_cart.php">
<input type="hidden" name="product_id" value="<?= $p['id'] ?>">
<input type="number" name="quantity" value="1" min="1" max="<?= $p['stock'] ?>" required>
<button type="submit"><i class="fas fa-cart-plus"></i> Add</button>
</form>
</div>
<?php endforeach; ?>
</div>

<!-- Order History -->
<h2>Your Orders</h2>
<table class="table">
<thead>
<tr>
<th>ID</th><th>Total Amount</th><th>Status</th><th>Ordered At</th>
</tr>
</thead>
<tbody>
<?php foreach($ordersList as $o): ?>
<tr>
<td><?= htmlspecialchars($o['id']) ?></td>
<td>$<?= htmlspecialchars($o['total_amount']) ?></td>
<td>
<?php
switch(strtolower($o['status'])){
    case 'pending': echo '<span class="status-pending">Pending</span>'; break;
    case 'completed': echo '<span class="status-completed">Completed</span>'; break;
    case 'cancelled': echo '<span class="status-cancelled">Cancelled</span>'; break;
}
?>
</td>
<td><?= htmlspecialchars($o['created_at']) ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

</div>
</body>
</html>
